//
//  sampleffi.h
//  SampleFFI
//
//  
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CallBack.h"

@interface sampleffimethod : NSObject

+ (NSString *) memberRegister:(NSNumber *) experience withName:(NSString *) name andBool:(BOOL) isMarriedBool andprogLang:(NSArray *) progLang;
+ (void) asyncmemberRegister:(NSNumber *) experience withName:(NSString *) name andBool:(BOOL) isMarriedBool andprogLang:(NSArray *) progLang andCallback:(CallBack *) callback;
+ (void) onJSMethodClickActivity;

@end

//
//  SampleIphoneScreen.m
//  VM
//
//  author: Kony Solution
//  
//

#import "SampleIphoneScreen.h"

@implementation SampleIphoneScreen
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    self.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    CGRect labelFrame = CGRectMake(20, 50, 280, 40);
    UILabel* label = [[UILabel alloc] initWithFrame: labelFrame];
	label.textAlignment = UITextAlignmentCenter;
    [label setText:@"You are in Native Screen"];
    CGRect buttonFrame = CGRectMake(50, 120, 220, 40);
	UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	button.frame = buttonFrame;
    [button setTitle:@"Go Back to Kony App" forState: UIControlStateNormal];
    [button addTarget: self action: @selector(onButtonClickRemoveView:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview: label];
    [self.view addSubview:button];
    [self.view setBackgroundColor: [UIColor purpleColor]];
    [self.view setTag:1212];
}

- (void)onButtonClickRemoveView: (id) sender
{
    [[[[UIApplication sharedApplication] keyWindow] viewWithTag:1212] removeFromSuperview];
}


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

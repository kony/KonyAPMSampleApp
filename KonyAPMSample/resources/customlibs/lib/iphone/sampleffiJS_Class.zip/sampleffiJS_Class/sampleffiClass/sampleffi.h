
//

//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CallBack.h"

@interface sampleffi : NSObject{

}

- (NSString *) memberRegister:(NSNumber *) experience withName:(NSString *) name andBool:(BOOL) isMarriedBool andprogLang:(NSArray *) progLang;
- (void) asyncmemberRegister:(NSNumber *) experience withName:(NSString *) name andBool:(BOOL) isMarriedBool andprogLang:(NSArray *) progLang andCallback:(CallBack *) callback;
- (void) onJSClickActivity;

@end
